import sys
import time

data = sys.stdin.readlines()
lines = []
dict = {}


def data_prep():
    for index in enumerate(data):
        line = data[index]
        if (line!=""):
            if line.endswith("\n"):
                line = line.strip()
            line = line.split(" ")
            (id_1, id_2) = (int(line[0]), int(line[1]))
            if id_1 in dict:
                dict[id_1].append(id_2)
            else:
                dict[id_1] = [id_2]
            if id_2 in dict:
                dict[id_2].append(id_1)
            else:
                dict[id_2] = [id_1]










if __name__ == "__main__":
    #start_time = time.time()
    data_prep()