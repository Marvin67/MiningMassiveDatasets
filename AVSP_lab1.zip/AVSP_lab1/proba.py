
import hashlib

file_name = "R_in.txt"
shingles_list = []




def data_prep():
    num_of_texts = 0

    try:
        f = open(file_name, "r")
    except IOError:
        print("Could not read file:", file_name)

    first_line = f.readline()
    if first_line.endswith("\n"):
        first_line = first_line[:-1]
        num_of_texts = int(first_line)

    for i in range(num_of_texts):
        line = f.readline()
        if line.endswith("\n"):
            line = line [:-1]
            l = line.split(" ")

            sim(l)

    line = f.readline()
    if line.endswith("\n"):
        line = line[:-1]
    num_of_queries = int(line)

    #print(shingles_list)
    #print(queries)
    #print("N =",num_of_texts," Q =", num_of_queries )

    similarity_check(shingles_list, num_of_texts, num_of_queries, f)




def similarity_check(shingles_list,num_of_texts, num_of_queries,f):
    print(num_of_texts,"num of texts")
    print(num_of_queries,"num of queries")
    output_list = []

    for i in range(num_of_queries):
        line = f.readline()
        if line.endswith("\n"):
            line = line[:-1]
            l = line.split(" ")
        else:
            print("A line didn't end with 'next line' ", l)
            exit(1)

        (reference_index, k) = int(l[0]),int(l[1])
        #print(reference_index,k)

        if (reference_index < 0 or reference_index > int(num_of_texts - 1)):
            print("Invalid input for I", reference_index, num_of_texts - 1)
            exit(2)
        if (k < 0 or k > 31):
            print("Invalid input for K", k)
            exit(3)


        similar_texts_cnt = 0

        for sh in range(len(shingles_list)):
             #reference_shingle = shingles_list[reference_index]
             #print(reference_shingle)
             if (sh != reference_index ):
                x = shingles_list[reference_index]
                y = shingles_list[sh]

                hamm_dist = [(ord(a) ^ ord(b)) for a, b in zip(x,y)].count(1)

                if (hamm_dist <= k):
                    similar_texts_cnt +=1

        output_list.append(similar_texts_cnt)

    print(output_list)




def sim(text_n):
        h = [0]*128
        for term in text_n:
            #print (term)
            term_hash = hashlib.md5(str(term).encode("utf-8"))
            term_hash_bin = bin(int(term_hash.hexdigest(), 16))[2:].rjust(128, "0")

            i=0
            for bit in term_hash_bin:
                if bit=="1":
                    h[i]+=1
                else:
                    h[i]-=1
                i+=1

        sh_final = ""
        for value in h:
            if value >=0:
                sh_final = sh_final+"1"
            else:
                sh_final = sh_final+"0"

        shingles_list.append(str(sh_final))
        #shingles_list.append( str(hex(int(sh_final, 2)))[2:] )
        #print(len(shingles)) // bit ce ih N, za N  ulaznih tekstova





if __name__ == "__main__":
    data_prep()
