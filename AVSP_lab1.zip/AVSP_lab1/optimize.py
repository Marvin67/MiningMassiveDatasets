
import hashlib

file_name = "R_in.txt"
shingles_list = []




def data_prep():
    num_of_texts = 0
    queries = []

    try:
        f = open(file_name, "r")
    except IOError:
        print("Could not read file:", file_name)

    first_line = f.readline()
    if first_line.endswith("\n"):
        first_line = first_line[:-1]
        num_of_texts = int(first_line)

    for index,line in enumerate(f, start = 1):
        if line.endswith("\n"):
            line = line [:-1]
            l = line.split(" ")

        if (index < num_of_texts + 1):
            sim(l)
        elif (index == num_of_texts + 1):
                num_of_queries = int(line)
                print("queries num: ", num_of_queries)
        else:
            queries.append(l)


    #print(shingles_list)
    #print(queries)
    #print("N =",num_of_texts," Q =", num_of_queries )

    similarity_check(shingles_list, queries, num_of_texts)




def similarity_check(shingles_list, queries, num_of_texts):
    print(num_of_texts,"num of texts")
    output_list = []
    for q in queries:
        if ((q[0])=="" or (q[1])==""):
            print("something_empty",q)
        reference_index, k = int(q[0]),int(q[1])


        if (reference_index < 0 or reference_index > int(num_of_texts - 1)):
            print("Invalid input for I", reference_index, num_of_texts - 1)
            exit(1)
        if (k < 0 or k > 31):
            print("Invalid input for K")
            exit(2)


        similar_texts_cnt = 0
        #print( reference_doc, k)
        for i in range(len(shingles_list)):
            #reference_shingle = shingles_list[reference_index]
            #print(reference_shingle)
            if (i != reference_index ):
                x = shingles_list[reference_index]
                y = shingles_list[i]

                hamm_dist = [(ord(a) ^ ord(b)) for a, b in zip(x,y)].count(1)
                #print(reference_index,i,hamm_dist)
                if (hamm_dist <= k):
                    similar_texts_cnt+=1
        output_list.append(similar_texts_cnt)
        #print("num of texts that differ in k or less bits:", similar_texts_cnt)
        #print("\n")
    print(output_list)














def sim(text_n):
        h = [0]*128
        for term in text_n:
            #print (term)
            term_hash = hashlib.md5(str(term).encode("utf-8"))
            term_hash_bin = bin(int(term_hash.hexdigest(), 16))[2:].rjust(128, "0")

            i=0
            for bit in term_hash_bin:
                if bit=="1":
                    h[i]+=1
                else:
                    h[i]-=1
                i+=1

        sh_final = ""
        for value in h:
            if value >=0:
                sh_final = sh_final+"1"
            else:
                sh_final = sh_final+"0"

        shingles_list.append(str(sh_final))
        #shingles_list.append( str(hex(int(sh_final, 2)))[2:] )
        #print(len(shingles)) // bit ce ih N, za N  ulaznih tekstova





if __name__ == "__main__":
    data_prep()
