import hashlib

file_name = "test.txt"
num_of_texts = 0
shingles = []



def data_prep():

    try:
        f = open(file_name, "r")
    except IOError:
        print("Could not read file:", file_name)


    for index,line in enumerate(f, start = 0):
        if line.endswith("\n"):
            line = line [:-1]
            l = line.split(" ")


        if (index == 0):
                num_of_texts = int(line)
        elif (num_of_texts != 0 and index == num_of_texts + 1):
                num_of_queries = int(line)
                break
        else:
            sim(l)

    print(shingles)




    #print (num_of_texts)
    #print(num_of_queries)

def sim(text_n):
        h = [0]*128
        for term in text_n:
            #print (term)
            term_hash = hashlib.md5(str(term).encode())
            term_hash_bin = bin(int(term_hash.hexdigest(), 16))[2:].rjust(128, "0")

            i=0
            for bit in term_hash_bin:
                if bit=="1":
                    h[i]+=1
                else:
                    h[i]-=1
                i+=1

        sh_final = ""
        for value in h:
            if value >=0:
                sh_final = sh_final+"1"
            else:
                sh_final = sh_final+"0"
        shingles.append( str(hex(int(sh_final, 2)))[2:] )
        #print(len(shingles)) // bit ce ih N, za N  ulaznih tekstova

















if __name__ == "__main__":
    data_prep()
