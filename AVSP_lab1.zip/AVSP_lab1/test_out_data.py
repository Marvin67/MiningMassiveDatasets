file_name = "R.out"
output_file = "output.txt"


if __name__ == "__main__":
    result_list = []
    f1 = open(file_name, "r" )
    f2 = open(output_file, "r")
    for line in f1:
        if line.endswith("\n"):
            line = line [:-1]
            line = str(line)
            result_list.append(int(line))
    print(result_list)
    print(len(result_list))

    for line in f2:
        if line.endswith("\n"):
            line = line[:-1]
        line = line.replace(' ', '')
        line = line.replace('[', '')
        line = line.replace(']', '')
        numbers = line.split(",")
        numbers = [int(num) for num in numbers]
        print(len(numbers))
        print(numbers)

    test_list1 = result_list.sort()
    test_list2 = numbers.sort()

    # using == to check if
    # lists are equal
    if test_list1 == test_list2:
        print("The lists are identical")
    else:
        print("The lists are not identical")




