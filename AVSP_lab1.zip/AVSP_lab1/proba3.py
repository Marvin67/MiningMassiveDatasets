import hashlib
from hexhamming import hamming_distance

a = "hello"
b = "jelly"



m_a = hashlib.md5(str(a).encode("utf-8")).hexdigest()
m_b = hashlib.md5(str(b).encode("utf-8")).hexdigest()

a_bin = bin(int(m_a, 16))[2:].rjust(128, "0")
b_bin = bin(int(m_b, 16))[2:].rjust(128, "0")


a_list = [(ord(a) ^ ord(b)) for a, b in zip(a_bin,b_bin)]
print(a_list.count(1))
#print(hamming_distance(m_a,m_b))


new_a = hex( int (str(a_bin), 2) )[2:]
new_b = hex( int (str(b_bin), 2) )[2:]

print(hamming_distance(new_a,new_b))

#len(hex( int (sh_final, 2) )[2:].zfill(32)