nodes = 7
INF = 1000000
distArray = [0 for i in range(nodes)]
vistSet = [0 for i in range(nodes)]
V = nodes

broji_pojavnost = [0]*nodes



graph = [[0, 1, 2, 0, 3,0,0],
         [1, 0, 0, 2, 0,0,0],
         [2, 0, 0, 1, 0,0,0],
         [0, 2, 1, 0, 0,2,4],
         [3, 0, 0, 0, 0,0,0],
         [0, 0, 0, 2, 0,0,2],
         [0, 0, 0, 4, 0,2,0]
         ];


edge_betw = {(0,1):0,(0,2):0,(1,3):0,(2,3):0,(0,4):0,(3,6):0,(3,5):0,(5,6):0}



def minDistance(distArray, vistSet):
    min = INF

    for v in range(V):
        if distArray[v] < min and vistSet[v] == False:
            min = distArray[v]
            min_index = v
    return min_index

def dijkstra(srcNode):

        putevi = [set() for i in range(nodes)]

        for i in range(0,V):
            distArray[i] = INF
            vistSet[i] = False
            distArray[srcNode] = 0
        for i in range(0,V):

            u = minDistance(distArray, vistSet)
            vistSet[u] = True

            for v in range(0,V):

                if graph[u][v] > 0 and vistSet[v] == False and distArray[v] >= distArray[u] + graph[u][v]:

                    if distArray[v] > distArray[u] + graph[u][v]:
                        distArray[v] = distArray[u] + graph[u][v]

                    putevi[v].add((u,v))

        for a in range(0,len(putevi)):
            if putevi[a] != []:
                broji_pojavnost[a] = len(putevi[a])
                for i in putevi[a]:
                    if (i[0] != srcNode):
                        prethodni = putevi[i[0]]
                        #print(putevi[a],prethodni)
                        putevi[a] = set (list(putevi[a])+list(prethodni))
                        if (broji_pojavnost[i[0]]> broji_pojavnost[a]):
                            broji_pojavnost[a] = broji_pojavnost[i[0]]


        print(broji_pojavnost)
        return putevi


def calc(putevi):
    for j in range(0, len(putevi)):
        for brid in putevi[j]:
            (x,y) = brid[0],brid[1]
            s = sorted( (x,y) )
            edge_betw[tuple(s)]+= 1/broji_pojavnost[j]



if __name__ == "__main__":
    putevi = dijkstra(0) # treba za sve pozvati
    calc(putevi)
    print(edge_betw)




