import numpy as np
import sys
from decimal import Decimal, ROUND_HALF_UP
import time


data = sys.stdin.readlines()
ratings = []

def get_pairs(list_size):
    num_of_items_list = list(range(0, list_size))
    res = [(p1, p2) for i, p1 in enumerate(num_of_items_list) for p2 in num_of_items_list[i + 1:]]
    return res

def cos_sim(x,y):
    return np.dot(x, y)/(np.sqrt(np.dot(x, x))*np.sqrt(np.dot(y, y)))


def data_prep():

    first_line = data[0]
    if first_line.endswith("\n"):
        first_line = first_line.strip()
    first_line = first_line.split(" ")
    n = int(first_line[0])
    m = int(first_line[1])
    #print(n,m)
    if (n>100 or m>100):
        print("N or M is greater than 100.")
        exit(1)

    for index in range(1, n+1):
        line = data[index].rstrip("\n").rstrip(" ")
        item_rating = list(line.split(" "))
        item_rating = [r.replace('X', '0') for r in item_rating]
        item_rating = list(map(float, item_rating))

        ratings.append(item_rating)
        initial_matrix = np.array(ratings)
        ratings_matrix_user = np.array(ratings)
        ratings_matrix_item = np.array(ratings)


    #---Matrix for USER-USER-------------------------------------------------------------------
    for col in range(0, m):
            col_arr = ratings_matrix_user[:, col]
            avg = sum(col_arr) / (len(col_arr) - np.count_nonzero(col_arr == 0))
            ratings_matrix_user[:, col] = np.where(col_arr == 0, 0, col_arr - avg)

    #---Matrix for ITEM-ITEM-------------------------------------------------------------------
    for row_index in range(0, n):
        row_arr = ratings_matrix_item[row_index]
        avg = sum(row_arr) / (len(row_arr) - np.count_nonzero(row_arr == 0))
        ratings_matrix_item[row_index] = np.where(row_arr == 0, 0, row_arr - avg)

    #---GET QUERY-------------------------------------------------------------------------------

    num_of_queries = data[n+1]
    if num_of_queries .endswith("\n"):
        num_of_queries = int(num_of_queries.strip())
    g=0
    for index in range(n+2, n+2+num_of_queries):
        query = data[index].strip().split(" ")
        (i,j,t,k) = (int(query[0]),int(query[1]),int(query[2]),int(query[3]))
        i -= 1
        j -= 1


    #---USER-USER-------------------------------------------------------------------------------

        if (t==1):
            sim_list_users = np.empty((m, 0)).tolist()

            res_1 = get_pairs(m)


            for pair in res_1:
                (index_1, index_2) = pair
                if (index_1!= index_2):
                    a = ratings_matrix_user[:, index_1]
                    b = ratings_matrix_user[:, index_2]
                    cos_ab = cos_sim(a,b)
                    if (cos_ab >0):
                        sim_list_users[index_1].append([index_2, cos_ab])
                        sim_list_users[index_2].append([index_1, cos_ab])

            top_users = sorted(sim_list_users[j], key = lambda x: x[1],reverse=True)
            numerator =0
            denominator=0
            for tuple in top_users:
                user = tuple[0]
                sim = tuple[1]
                if (initial_matrix[i, user] != 0 and k>0):
                    numerator += sim * initial_matrix[i, user]
                    denominator += sim
                    k-=1




    #---ITEM-ITEM-------------------------------------------------------------------------------

        else:
            sim_list_items = np.empty((m, 0)).tolist()

            if (m!=n):
                res_2 = get_pairs(n)
            else :
                res_2 = res_1

            for pair in res_2:
                (index_1, index_2) = pair
                if (index_1 != index_2):
                    c = ratings_matrix_item[index_1]
                    d = ratings_matrix_item[index_2]
                    cos_ab = cos_sim(c, d)
                    if (cos_ab >= 0):
                        sim_list_items[index_1].append([index_2, cos_ab])
                        sim_list_items[index_2].append([index_1, cos_ab])

            top_items = sorted(sim_list_items[i], key=lambda x: x[1], reverse=True)
            numerator = 0
            denominator = 0
            for tuple in top_items:
                item = tuple[0]
                sim = tuple[1]
                if (initial_matrix[item, j] != 0 and k>0):
                    numerator += sim * initial_matrix[item, j]
                    denominator += sim
                    k-=1

        predicted_rating = Decimal(Decimal(numerator / denominator).quantize(Decimal('.001'), rounding=ROUND_HALF_UP))
        print(predicted_rating)

    print("--- %s seconds ---" % (time.time() - start_time))





if __name__ == "__main__":
    start_time = time.time()
    data_prep()