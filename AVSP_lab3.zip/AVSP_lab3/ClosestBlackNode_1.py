import sys
import time

data = sys.stdin.readlines()
node_type = []
blacks = []
queue = []
udaljenosti = []


def data_prep():

    first_line = data[0]
    if first_line.endswith("\n"):
        first_line = first_line.strip()
    first_line = first_line.split(" ")
    n = int(first_line[0])
    e = int(first_line[1])

    for index in range(1, n+1):
        line = data[index].rstrip("\n").rstrip(" ")
        node_type.insert(index-1,int(line))
        if (int(line)==1):
            blacks.append(index-1)
    #print(node_type)



    #-----MAKE A DICT FOR GRAPH-------------------------------------------------------------------------------------
    graph = [[] for i in range(0, n)]

    for index in range(n+1,n+1+e):
        line = data[index].rstrip("\n").rstrip(" ")
        nodes = list(line.split(" "))

        (node_1,node_2) = (int(nodes[0]),int(nodes[1]))
        graph[node_1].append(node_2)
        graph[node_2].append(node_1)

    #for i in range(len(graph)):
       # graph[i] = sorted(graph[i])
    #print(graph)


    calculate(graph, n)

def calculate(graph,n):
    dist = [-1]*n
    for vertice in range (0,n):
        v = [0]*n
        bfs(vertice, graph, v, dist,n )





def bfs(vertice,graph,v, dist,n):
    bla = []
    queue = []
    queue.append([vertice,0])
    while (queue) :
        first_el = queue[0]
        (node, distance) = (first_el[0], first_el[1])


        v[node] = 1
        del queue[0]

        if (node_type[node]==1):
            bla =sorted(bla)
            bla = sorted(bla, key=lambda x: x[1])
            print (bla)
            #dist[vertice] = distance
            if (not bla):



                print(node, distance)
            else:
                print(bla[0][0],bla[0][1])
            return



        neigbours = graph[node]
        for index in range (0, len(neigbours)):
            if (v[neigbours[index]] == 0 ):
                d = distance + 1
                if (d>10):
                    print(-1,-1)
                if (neigbours[index] in blacks):
                    bla.append([neigbours[index], d])
                queue.append([neigbours[index], d])

    print(-1,-1)


if __name__ == "__main__":
    data_prep()