import numpy as np
import sys
from decimal import Decimal, ROUND_HALF_UP
import time

data = sys.stdin.readlines()
lines = []


def data_prep():

    first_line = data[0]
    if first_line.endswith("\n"):
        first_line = first_line.strip()
    first_line = first_line.split(" ")
    n = int(first_line[0])
    beta = float(first_line[1])
    #print(n,m)
    if (n < 1 or n > 100000):
        print("Wrong input for n parameter")
        exit(1)
    if (beta < 0.0 or beta > 1.0):
        print("Wrong input for beta parameter")
        exit(1)

    node_dict = dict()
    for x in range(0, n):
        node_dict[int(x)] = [0,[]]

    #print(n,beta)
    for index in range(1, n+1):
        line = data[index].rstrip("\n").rstrip(" ")
        nodes = list(line.split(" "))
        node_index = index - 1
        node_dict[node_index][0] = len(nodes)
        for node in nodes:
            node_dict[int(node)][1].append(node_index )

    print(node_dict)

    #-------read queries------------------------------------------------------
    num_of_queries = data[n+1]
    if num_of_queries .endswith("\n"):
        num_of_queries = int(num_of_queries.strip())

    for index in range(n+2, n+2+num_of_queries):
        query = data[index].strip().split(" ")
        (node_q, k) = (int(query[0]), int(query[1]) ) # k = iteration
        #print(node_q,k)
        rank(n, node_q, k)


def rank(n, node_q, k):
    r = np.full( (1,n), 1/n , dtype=float )
    r = r.transpose()
    m_0 = np.matrix([ [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                 [0, 0, 0, 0, 0, 0, 0.5, 0, 0, 0],
                 [1/3, 0, 1, 0, 0, 0.5, 0, 0, 0, 0],
                 [1/3, 0, 0, 0, 0, 0, 0, 0, 1/3, 0],
                 [0, 0, 0, 0, 1, 0.5, 0, 0, 0, 0],
                 [1/3, 0, 0, 0, 0, 0, 0.5, 0, 0, 0],
                 [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
                 [0, 0, 0, 0, 0, 0, 0, 1, 1/3, 0],
                 [0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                 [0, 0, 0, 1, 0, 0, 0, 0,  1 / 3,0],
                 ])

    m = np.multiply(m_0,0.8)

    for i in range (0,k):
        if (i==0):
            res = np.dot(m,r)
        else:
            res = np.dot(m, res)
        s = np.sum(res)
        res = np.add(res,(1-s)/n)

    wanted_node = np.array(res).ravel()[node_q]
    print( Decimal(Decimal(wanted_node).quantize(Decimal('.0000000000'), rounding=ROUND_HALF_UP)))














if __name__ == "__main__":
    start_time = time.time()
    data_prep()