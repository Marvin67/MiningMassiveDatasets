import sys
import time

data = sys.stdin.readlines()
node_type = []
blacks = []




def data_prep():

    first_line = data[0]
    if first_line.endswith("\n"):
        first_line = first_line.strip()
    first_line = first_line.split(" ")
    n = int(first_line[0])
    e = int(first_line[1])

    for index in range(1, n+1):
        line = data[index].rstrip("\n").rstrip(" ")
        node_type.insert(index-1,int(line))
        if (int(line)==1):
            blacks.append(index-1)
    #print(node_type)



    #-----MAKE A DICT FOR GRAPH-------------------------------------------------------------------------------------
    pamti_graf = [[] for i in range(0, n)]

    for index in range(n+1,n+1+e):
        line = data[index].rstrip("\n").rstrip(" ")
        nodes = list(line.split(" "))

        (node_1,node_2) = (int(nodes[0]),int(nodes[1]))
        pamti_graf[node_1].append(node_2)
        pamti_graf[node_2].append(node_1)



    #print("--- %s seconds ---" % (time.time() - start_time))



    for vertice in range (0,n):
        v = [0]*n
        bfs(vertice,pamti_graf , v,n )


def bfs(vertice,pamti_graf ,v,n):
    zadnji_d = 1000000
    bla = []
    red = []
    red.append([vertice,0])
    while (red) :
        first_el = red[0]
        (node, distance) = (first_el[0], first_el[1])
        v[node] = 1


        if (node_type[node]==1):

            #print (bla)

            if (not bla):

                print(node, distance)
            else:
                print(min(bla),distance)
            return
        del red[0]
        neigbours = pamti_graf [node]
        for index in range (0, len(neigbours)):
            if (v[neigbours[index]] == 0 ):
                d = distance + 1
                if (neigbours[index] in blacks and d<=zadnji_d):
                        bla.append(neigbours[index])
                        zadnji_d = d
                red.append([neigbours[index], d])

    print(-1,-1)


if __name__ == "__main__":
    start_time = time.time()
    data_prep()