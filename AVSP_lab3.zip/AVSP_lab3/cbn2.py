import sys
import time

data = sys.stdin.readlines()
node_type = []
blacks = []




def data_prep():
    first_line = data[0]
    if first_line.endswith("\n"):
        first_line = first_line.strip()
    first_line = first_line.split(" ")
    n = int(first_line[0])
    e = int(first_line[1])

    queue = []
    v = [0] * n
    koji = [-1] * n

    for index in range(1, n+1):
        line = data[index].rstrip("\n").rstrip(" ")
        node_type.insert(index-1,int(line))
        if (int(line)==1):
            b = index-1
            blacks.append(b)
            koji[b] = b
            v[b]=1
            queue.append([b, 0])
    #print(node_type)



    #-----MAKE A DICT FOR GRAPH-------------------------------------------------------------------------------------
    dic = [[] for i in range(0, n)]



    for index in range(n+1,n+1+e):
        line = data[index].rstrip("\n").rstrip(" ")
        nodes = list(line.split(" "))

        (node_1,node_2) = (int(nodes[0]),int(nodes[1]))
        dic[node_1].append(node_2)
        dic[node_2].append(node_1)


    distance = [0] * n



    while(queue):
        first = queue[0][0]
        del queue[0]
        neigh = dic[first]

        for ind in neigh:
            if (v[ind]==0):
                queue.append([ind,distance[first]+1])
                if (first in blacks):
                    koji[ind]= first
                else:
                    koji[ind]=koji[first]
                distance[ind]= distance[first]+1
                v[ind] = 1



    for j in range(0, n):
        print(koji[j], distance[j])

    #print("--- %s seconds ---" % (time.time() - start_time))









if __name__ == "__main__":
    start_time = time.time()
    data_prep()