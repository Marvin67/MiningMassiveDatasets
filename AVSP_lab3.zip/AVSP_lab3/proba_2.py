# Python3 program to demonstrate distance to
# nearest source problem using BFS
# from each vertex

N = 100
inf = 100

# This array stores the distances of the
# vertices from the nearest source
dist = [0 for i in range(N)];

# a hash array where source[i] = 1
# means vertex i is a source
source = [0 for i in range(N)];

# The BFS Queue
# The pairs are of the form (vertex, distance from current source)
BFSQueue = []

# visited array for remembering visited vertices
visited = [0 for i in range(N)]


# The BFS function
def BFS(graph, start):
    # clearing the queue
    while (len(BFSQueue) != 0):
        BFSQueue.pop()


    # append starting vertices
    BFSQueue.append([start, 0])

    while (len(BFSQueue) != 0):

        s = BFSQueue[0][0]
        d = BFSQueue[0][1]

        visited[s] = 1
        BFSQueue.pop(0)
        # stop at the first source we reach during BFS
        if (source[s] == 1):
            dist[start] = d
            print(start, dist[start],s)
            return

        # Pushing the adjacent unvisited vertices
        # with distance from current source = this
        # vertex's distance  + 1
        for i in range(len(graph[s])):

            if (visited[graph[s][i]] == 0):
                BFSQueue.append([graph[s][i], d + 1])


# This function calculates the distance of each
# vertex from nearest source
def nearestTown(graph, n, sources, S):
    global source, dist

    # reseting the source hash array
    for i in range(0,n):
        source[i] = 0

    for i in range(S):
        source[sources[i]] = 1

    # loop through all the vertices and run
    # a BFS from each vertex to find the distance
    # to nearest town from it
    for i in range(0,n):
        for j in range(0,n):
            visited[j] = 0
        koji = BFS(graph, i)

    # Printing the distances
    #for i in range(1, n + 1):
        #print('{} {}'.format(i, dist[i]))




def addEdge(graph, u, v):
    graph[u].append(v)
    graph[v].append(u)



if __name__ == '__main__':
    # Number of vertices
    n = 6

    graph = [[] for i in range(n)]

    # Edges
    addEdge(graph, 0, 1)
    addEdge(graph, 0, 5)
    addEdge(graph, 1, 5)
    addEdge(graph, 1, 2)
    addEdge(graph, 2, 5)
    addEdge(graph, 4, 3)
    addEdge(graph, 5, 4)
    addEdge(graph, 2, 3)
    addEdge(graph, 4, 2)



    # Sources
    sources = [0, 4]

    S = len(sources)
    for el in graph:
        el = sorted(el)
    print(graph)

    nearestTown(graph, n, sources, S)
