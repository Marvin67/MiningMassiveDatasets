import sys
import time

data = sys.stdin.readlines()
node_type = []
blacks = []



def data_prep():
    first_line = data[0]
    if first_line.endswith("\n"):
        first_line = first_line.strip()
    first_line = first_line.split(" ")
    n = int(first_line[0])
    e = int(first_line[1])

    for index in range(1, n+1):
        line = data[index].rstrip("\n").rstrip(" ")
        node_type.insert(index-1,int(line))
        if (int(line)==1):
            blacks.append(index-1)
    #print(node_type)



    #-----MAKE A DICT FOR GRAPH-------------------------------------------------------------------------------------
    graph = [[] for i in range(0, n)]



    for index in range(n+1,n+1+e):
        line = data[index].rstrip("\n").rstrip(" ")
        nodes = list(line.split(" "))

        (node_1,node_2) = (int(nodes[0]),int(nodes[1]))
        graph[node_1].append(node_2)
        graph[node_2].append(node_1)

    #for i in range(len(graph)):
       # graph[i] = sorted(graph[i])
    #print(graph)


    calculate(n,graph)
    print("--- %s seconds ---" % (time.time() - start_time))

def calculate(n,graph):
    g = graph
    queue = []
    v = [0]*n

    for b in blacks:
        v[b]=1
        queue.append([b,0])

    distance, koji = bfs(queue,g,v,n)

    for j in range(0,n):
        print(koji[j],distance[j])


def bfs(queue,g,v,n):
    koji = [-1]*n
    for b in blacks:
        koji[b]=b
    distance = [0] * n
    while(queue):
        first = queue[0][0]
        queue.pop(0)

        neigh = g[first]

        for index in neigh:
            if (v[index]==0):
                queue.append([index,distance[first]+1])
                if (first in blacks):
                    koji[index]= first
                else:
                    koji[index]=koji[first]
                distance[index]= distance[first]+1
                v[index] = 1
    #print(koji)
    return distance,koji









if __name__ == "__main__":
    start_time = time.time()
    data_prep()