import numpy as np
import sys
from decimal import Decimal, ROUND_HALF_UP
import time

data = sys.stdin.readlines()
lines = []
m = []


def data_prep():

    first_line = data[0]
    if first_line.endswith("\n"):
        first_line = first_line.strip()
    first_line = first_line.split(" ")
    n = int(first_line[0])
    beta = float(first_line[1])
    #print(n,m)
    if (n < 1 or n > 100000):
        print("Wrong input for n parameter")
        exit(1)
    if (beta < 0.0 or beta > 1.0):
        print("Wrong input for beta parameter")
        exit(1)

    node_dict = dict()
    for x in range(0, n):
        node_dict[int(x)] = [0,[]]

    #print(n,beta)
    for index in range(1, n+1):
        line = data[index].rstrip("\n").rstrip(" ")
        nodes = list(line.split(" "))
        node_index = index - 1
        node_dict[node_index][0] = len(nodes)
        for node in nodes:
            node_dict[int(node)][1].append(node_index )

    #print(node_dict)




    #--QUERIES------------------------------------------------------

    num_of_queries = data[n+1]
    if num_of_queries .endswith("\n"):
        num_of_queries = int(num_of_queries.strip())

    for index in range(n+2, n+2+num_of_queries):
        query = data[index].strip().split(" ")
        (node_q, k) = (int(query[0]), int(query[1]) ) # k = iteration
        r=[1/n]*n

        rank(r,n,node_dict,node_q,k)

    print("--- %s seconds ---" % (time.time() - start_time))





def rank(r,n,node_dict,node_q,k):
    r = np.full((1, n), 1/n).transpose()
    r_1 = np.full((1, n), 1/n).transpose()

    for iteration in range(1,k+1):
        #print(iteration, r)

        s = 0
        zbroj = 0
        for j in range(0,n):
            #if iteration==0: print("za ",j, " ")
            node_list = node_dict.get(j)[1]
            if (len(node_list)!=0):
                for node in node_list:
                    zbroj +=  ( r[node]/ node_dict[node][0])

                r_1[j] = 0.8*zbroj
                s += r_1[j]
                zbroj = 0

            else:
                r_1[j] = 0.0

        for j in range(0, n):
            r_1[j] += (1-s)/n



        r = r_1
        r_1 = np.full((1, n), 0.0).transpose()
        #print(iteration, r)




    print( Decimal(Decimal(r.ravel()[node_q]).quantize(Decimal('.0000000000'), rounding=ROUND_HALF_UP)))
























if __name__ == "__main__":
    start_time = time.time()
    data_prep()