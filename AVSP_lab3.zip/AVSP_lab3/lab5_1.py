import sys
import time
import numpy as np

data = sys.stdin.readlines()
lines = []
adj_nodes = {}
edge_weights = {}
vectors = {}
map_index = {}



def data_prep():
    for index, line in enumerate(data):
        line = data[index]
        if line == '\n':
            start_index = index + 1

    k = 0
    for i in range(start_index, len(data)):

        line = data[i]
        #print(line)
        if line.endswith("\n"):
            line = line.strip()
        line = line.split(" ")
        id = line.pop(0)
        map_index[id] = k
        vectors[k] = np.array(line)

        k+=1

    print(map_index)

    for i in range(0, start_index):
        line = data[i]
        if line != '\n':
            if line.endswith("\n"):
                line = line.strip()

            line = line.split(" ")
            (id_1, id_2) = (map_index[line[0]], map_index[line[1]])
            edge_weights[(id_1, id_2)] = 0
            # print(id_1, id_2)
            if id_1 in adj_nodes:
                adj_nodes[id_1].append(id_2)
            else:
                adj_nodes[id_1] = [id_2]
            if id_2 in adj_nodes:
                adj_nodes[id_2].append(id_1)
            else:
                adj_nodes[id_2] = [id_1]

    calculate_weights()
    init_matrix()
    print(edge_weights)




def calculate_weights():

    for pair in edge_weights:
        a = vectors[pair[0]]
        b = vectors[pair[1]]
        edge_weights[pair] =  np.count_nonzero(a!=b) + 1

def init_matrix():
    n = len(adj_nodes)
    graph = [[0 for column in range(n)]
             for row in range(n)]
    for pair in edge_weights:
        (i,j) = (pair[0],pair[1])
        graph[i][j]=edge_weights[(i,j)]
        graph[j][i] = edge_weights[(i, j)]














if __name__ == "__main__":
    data_prep()