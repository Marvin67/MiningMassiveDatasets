nodes = 6
INF = 1000000
distArray = [0 for i in range(nodes)]
vistSet = [0 for i in range(nodes)]
V = nodes
putevi = [[] for i in range(nodes)]


graph = [[0, 1, 2, 0, 3, 0],
         [1, 0, 0, 2, 0, 0],
         [2, 0, 0, 1, 0, 0],
         [0, 2, 1, 0, 0, 1],
         [3, 0, 0, 0, 0, 0],
         [0, 0, 0, 1, 0, 0]];


edge_betw = {(0,1):0,(2,0):0,(1,3):0,(3,2):0,(0,4):0}


def minDistance(distArray, vistSet):
    min = INF

    for v in range(V):
        if distArray[v] < min and vistSet[v] == False:
            min = distArray[v]
            min_index = v
    return min_index

def dijkstra(srcNode):

        #putevi[srcNode] = str(srcNode)
        for i in range(0,V):
            distArray[i] = INF
            vistSet[i] = False
            distArray[srcNode] = 0
        for i in range(0,V):
            #print('glavna iteracija',i)
            u = minDistance(distArray, vistSet)
            vistSet[u] = True

            for v in range(0,V):
                #print('u',u, '','v',v)
                #print(distArray[v],'>',distArray[u],'+', graph[u][v])
                if graph[u][v] > 0 and vistSet[v] == False and distArray[v] >= distArray[u] + graph[u][v]:
                        distArray[v] = distArray[u] + graph[u][v]
                        putevi[v].append (str(u)+"-"+str(v))




        concatenate(putevi,srcNode)

def concatenate(putevi,srcNode):
    for i in range(0, len(putevi)):
        lista = putevi[i]
        if (putevi[i] != []):
            for k in range(0, len(lista)):

                first = int(lista[k][0])

                while (first != srcNode):
                    if (len(putevi[first]) == 1):
                        print(putevi[first][0])
                        lista[k] = putevi[first][0] + ',' + lista[k]

                        first = int(lista[k][0])
                    else:
                        print(first)
                        break

    print(putevi)

    print(putevi)
def count_edges(putevi,pamti):

    for i in range(0,nodes):
        if putevi[i]!='':
            paths = putevi[i].split(',')
            for path in paths:
                pair = path.split('-')
                pair = (int(pair[0]), int(pair[1]))










if __name__ == "__main__":
    dijkstra(0) # treba za sve pozvati
    print(putevi)



