import hashlib
from hexhamming import hamming_distance
import sys
import time


shingles_list = []
data = sys.stdin.readlines()


def data_prep():
    num_of_texts = 0

    first_line = data[0]
    if first_line.endswith("\n"):
        first_line = first_line.rstrip("\n")
        num_of_texts = int(first_line)
    else:
        print("Line didn't end properly while reading N.")
        exit(1)
    if (num_of_texts > 10**5):
        print("N is greater than 10**5.")
        exit(2)

    for i in range(1, num_of_texts + 1):
        line = data[i]
        if line.endswith("\n"):
            line = line.rstrip("\n")
            if line.endswith(" "):
                line = line.rstrip(" ")
            l = line.split(" ")
        else:
            print("Line didn't end properly while reading texts.")
            exit(1)
        sim(l)



    lsh_algorithm(shingles_list,num_of_texts)





def sim(text_n):
        h = [0]*128
        for term in text_n:
            #print (term)
            term_hash = hashlib.md5(str(term).encode("utf-8"))
            term_hash_bin = bin(int(term_hash.hexdigest(), 16))[2:].rjust(128, "0")

            i=0
            for bit in term_hash_bin:
                if bit=="1":
                    h[i]+=1
                else:
                    h[i]-=1
                i+=1

        sh_final = ""
        for value in h:
            if value >=0:
                sh_final = sh_final+"1"
            else:
                sh_final = sh_final+"0"


        shingles_list.append( hex( int (sh_final, 2) )[2:].zfill(32))



def lsh_algorithm(shingles_list,num_of_texts):
    candidates = {}
    b = 8
    bit_start = 28
    bit_end = 32


    for band in range (b):

        buckets = {}
        #print(num_of_texts)
        for temp_txt_index in range(num_of_texts):
            temp_sh = shingles_list[temp_txt_index]

            take_16_bits = temp_sh[bit_start:bit_end]
            int_value = int(take_16_bits, 16)

            bucket_texts = set()

            if (int_value in buckets.keys()):
                bucket_texts = buckets[int_value]

                for text_index_bucket in bucket_texts:
                    if (temp_txt_index not in candidates.keys()):
                        candidates[temp_txt_index] = set()
                    candidates[temp_txt_index].add(text_index_bucket)

                    if (text_index_bucket not in candidates.keys()):
                        candidates[text_index_bucket] = set()
                    candidates[text_index_bucket].add(temp_txt_index)


            bucket_texts.add(temp_txt_index)
            buckets[int_value] = bucket_texts

        bit_start -= 4
        bit_end -= 4


    similarity_check(shingles_list,num_of_texts, candidates)





def similarity_check(shingles_list,num_of_texts, candidates):
        output_list = []

        q_line = data[num_of_texts + 1]
        if q_line.endswith("\n"):
            q_line = q_line.rstrip("\n")
            num_of_queries = int(q_line)
        else:
            print("Line didn't end properly while reading Q.")
            exit(1)

        if (num_of_queries > 10 ** 5):
            print("Q is greater than 10**5.")
            exit(2)
        print(num_of_texts, num_of_queries)


        query_index = num_of_texts + 2
        for i in range(query_index, query_index + num_of_queries):
            line = data[i]
            if line.endswith("\n"):
                line = line.rstrip("\n")
                l = line.split(" ")
            else:
                print("Line didn't end properly while reading queries.")
                exit(1)

            (reference_index, k) = int(l[0]), int(l[1])
            # print(reference_index,k)

            if (reference_index < 0 or reference_index > int(num_of_texts - 1)):
                print("Invalid input for I", reference_index, num_of_texts - 1)
                exit(3)
            if (k < 0 or k > 31):
                print("Invalid input for K", k)
                exit(3)



            similar_texts_cnt = 0

            if (reference_index in candidates.keys()):
                similar_texts_list = candidates.get(reference_index)
                for sim_text_index in similar_texts_list:
                    if (reference_index != sim_text_index):
                        hamm_dist = hamming_distance(shingles_list[reference_index], shingles_list[sim_text_index])
                        if (hamm_dist <= k):
                            similar_texts_cnt += 1
            else:
                similar_texts_cnt = 0


            print(similar_texts_cnt)
        print("--- %s seconds ---" % (time.time() - start_time))








if __name__ == "__main__":
    start_time = time.time()
    data_prep()
    #print(shingles_list)
