file_r = "C.out"
file_my = "lista_rez_C.txt"

if __name__ == "__main__":
    result_list = []
    f1 = open(file_r, "r" )
    f2 = open(file_my, "r")

    data=f1.readlines()
    data_2=f2.readlines()
    i = 0
    for line in data:
        if line.endswith("\n"):
            line = line [:-1]
        if line.endswith(" "):
            line = line[:-1]

        line_2= data_2[i]
        if line.endswith("\n"):
            line_2 = line_2[:-1]
        line_2=line_2.rstrip()
        #print(len(line),len(line_2))
        if (line!=line_2):
            print("nius isti")
        #print(line,line_2,line==line_2)
        i+=1
