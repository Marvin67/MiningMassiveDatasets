file_name = "R.out"
output_file = "output.txt"

r_in = "R.in"
wtf_in = "wtf.txt"

r = open(r_in, "r")
wtf = open(wtf_in, "r")

print(len(r.read()))
print(len(wtf.read()))










if __name__ == "__main__":
    result_list = []
    f1 = open(file_name, "r" )
    f2 = open(output_file, "r")
    for line in f1:
        if line.endswith("\n"):
            line = line [:-1]
            line = str(line)
            result_list.append(int(line))
    #print(result_list)


    for line in f2:
        if line.endswith("\n"):
            line = line[:-1]
        line = line.replace(' ', '')
        line = line.replace('[', '')
        line = line.replace(']', '')
        numbers = line.split(",")
        numbers = [int(num) for num in numbers]

        #print(numbers)

    #print(len(result_list))
    #print(len(numbers))





