import numpy as np
import hashlib
np_bin_array = np.array([0, 1, 0, 0,1,1,1,1,1,1])
bhello = ''.join(map(str, np_bin_array))
xhello = hex(int(bhello, 2)).strip("0x")

x=np.array([-2,-3,1,4])
x[x > 0] = 1
x = np.where(x<=0,0,1)


print(np.zeros(128).astype(int))
print(hashlib.md5(str("faks").encode()))
print(int(hashlib.md5(str("faks").encode("utf-8")).hexdigest(), 16))

def sim(text_n):
    h = np.zeros(128)
    for term in text_n:
        term_hash_bin = bin(int(hashlib.md5(str(term).encode("utf-8")).hexdigest(), 16))[2:].rjust(128, "0")
        h = np.add(h, np.array(list(term_hash_bin), dtype=int))

    h = (2 * h - len(text_n)).astype(int)
    sh_final = np.where(h < 0, 0, 1)

    shingles_list.append(hex(int(''.join(map(str, sh_final)), 2))[2:].zfill(32))
