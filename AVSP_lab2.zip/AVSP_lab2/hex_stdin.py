import hashlib
from hexhamming import hamming_distance
import sys

shingles_list = []
data = sys.stdin.readlines()

def data_prep():
    num_of_texts = 0

    first_line = data[0]
    if first_line.endswith("\n"):
        first_line = first_line.rstrip("\n")
        num_of_texts = int(first_line)
    else:
        print("Line didn't end properly")
        exit(1)

    for i in range(1, num_of_texts + 1):
        line = data[i]
        if line.endswith("\n"):
            line = line.rstrip("\n")
            l = line.split(" ")
        else:
            print("Line didn't end properly")
            exit(2)
        sim(l)

    q_line = data[num_of_texts + 1]
    print(data[num_of_texts + 1])
    if q_line.endswith("\n"):
        q_line = q_line.rstrip("\n")
        num_of_queries = int(q_line)
    else:
        print("Line didn't end properly")
        exit(3)


    #print(shingles_list)
    #print(queries)
    #print("N =",num_of_texts," Q =", num_of_queries )

    similarity_check(shingles_list, num_of_texts, num_of_queries)




def similarity_check(shingles_list,num_of_texts, num_of_queries):
    #print(num_of_texts,"num of texts")
    #print(num_of_queries,"num of queries")
    output_list = []

    query_index = num_of_texts + 2
    for i in range(query_index, query_index + num_of_queries):
        line = data[i]
        if line.endswith("\n"):
            line = line.rstrip("\n")
            l = line.split(" ")
        else:
            print("Line didn't end properly")
            exit(4)



        (reference_index, k) = int(l[0]),int(l[1])
        #print(reference_index,k)

        if (reference_index < 0 or reference_index > int(num_of_texts - 1)):
            print("Invalid input for I", reference_index, num_of_texts - 1)
            exit(2)
        if (k < 0 or k > 31):
            print("Invalid input for K", k)
            exit(3)


        similar_texts_cnt = 0

        for sh in range(len(shingles_list)):
             #reference_shingle = shingles_list[reference_index]
             #print(reference_shingle)
             if (sh != reference_index ):

                hamm_dist = hamming_distance(shingles_list[sh],shingles_list[reference_index])
                if (hamm_dist <= k):
                    similar_texts_cnt +=1
        print(similar_texts_cnt)
        #output_list.append(similar_texts_cnt)

    #print((output_list))
    #with open("new_output.txt", "w") as f_out:
    #      f_out.write(str(output_list))




def sim(text_n):
        h = [0]*128
        for term in text_n:
            #print (term)
            term_hash = hashlib.md5(str(term).encode("utf-8"))
            term_hash_bin = bin(int(term_hash.hexdigest(), 16))[2:].rjust(128, "0")

            i=0
            for bit in term_hash_bin:
                if bit=="1":
                    h[i]+=1
                else:
                    h[i]-=1
                i+=1

        sh_final = ""
        for value in h:
            if value >=0:
                sh_final = sh_final+"1"
            else:
                sh_final = sh_final+"0"

        #shingles_list.append(str(sh_final))
        shingles_list.append( hex( int (sh_final, 2) )[2:].zfill(32))
        #print(len(shingles)) // bit ce ih N, za N  ulaznih tekstova



if __name__ == "__main__":
    data_prep()
