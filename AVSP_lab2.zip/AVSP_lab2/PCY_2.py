import sys
import time


data = sys.stdin.readlines()


def data_prep():
    first_line = data[0]
    if first_line.endswith("\n"):
        num_of_baskets = int(first_line.rstrip("\n"))

    second_line = data[1]
    if second_line.endswith("\n"):
        threshold = float(second_line.rstrip("\n"))

    third_line = data[2]
    if third_line.endswith("\n"):
        num_of_buckets = int(third_line.rstrip("\n"))

    threshold_new = int(threshold*num_of_baskets)
    pcy(num_of_baskets,threshold_new,num_of_buckets)




def pcy(n,s,num_of_buckets):
    baskets =[]
    items_cnt = []

    #------------Count the number of times each item appears in all baskets-------------------
    for index in range(3, n+3):
        line = data[index].rstrip("\n").rstrip(" ")
        basket = line.split(" ")
        basket = list(map(int, basket))
        baskets.append(basket)

        max_element = int( basket[-1])

        if (len(items_cnt) <= max_element):
                items_cnt[len(items_cnt): max_element] = [0] * ( max_element - len(items_cnt) + 1)
                for item in basket:
                    #print("prvi",len(items_cnt),int(item))
                    items_cnt[int(item)] += 1

        else:

            for item in basket:
                #print("drugi",len(items_cnt),int(item) )
                items_cnt[int(item)] += 1


    cnt_zeroes = 0
    for element in items_cnt:
        if (int(element)==0):
            cnt_zeroes+=1
    m = len(items_cnt)-cnt_zeroes
    #print(len(items_cnt), sorted(items_cnt))
    output_A = (m*(m-1))/2
    print(int(output_A))

    # --------------Hash pairs of items----------------------------------------------------------

    dict = {}

    for basket in baskets:
        res = [(p1, p2) for i, p1 in enumerate(basket) for p2 in basket[i + 1:]]

        for pair in res:
            (i,j) = pair
            if (items_cnt[i] >= s and items_cnt[j] >= s):
                hash = (i * m + j) % num_of_buckets

                if (hash not in dict.keys()):
                        dict[hash] = 1
                else:
                        dict[hash] = dict.get(hash) + 1

    #print("gotov_hashirao u pretince")

    # ------------------------------------------------------------------------------------------

    pairs = {}

    for basket in baskets:
        res = [(p1, p2) for i, p1 in enumerate(basket) for p2 in basket[i + 1:]]
        for pair in res:
            (i,j) = pair
            if (items_cnt[i] >= s and items_cnt[j] >= s):
                hash = (i * m + j) % num_of_buckets

                if dict.get(hash) >= s:
                    if ((i, j) not in pairs.keys()):
                        pairs[(i, j)] = 1
                    else:
                        pairs[(i, j)] = pairs.get((i, j)) + 1

    pair_frequencies = sorted(pairs.values(),reverse=True)
    output_P = len(pair_frequencies)
    print (output_P)

    #f=open("lista_rez_C.txt","w")
    #print(int(output_A), file=f)
    #print(output_P, file=f)

    for pair_freq in pair_frequencies:
        print(pair_freq)
        #print(pair_freq, file=f)





if __name__ == "__main__":
    #start_time = time.time()
    data_prep()